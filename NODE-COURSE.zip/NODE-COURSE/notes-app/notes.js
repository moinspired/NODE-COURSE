const fs = require('fs')
const chalk = require('chalk')



const addNote = (title, body) => {
    const notes = loadNotes()
    const duplicatNote = notes.find((note) => note.title === title )

    if(duplicatNote === undefined){
        notes.push({
            title: title,
            body: body
        })

        saveNotes(notes)
        console.log('New note added!')
    } else {
        console.log('Note title taken!')
        
    }
   

    console.log(duplicatNote)
}

const saveNotes = (notes) =>{
    const dataJSON = JSON.stringify(notes)
    fs.writeFileSync('note.json', dataJON)
}

const loadNotes = (note) => {
    try {
        const dataBuffor = fs.readFileSync('note.json')
        const dataJSON = dataBuffor.toString()
        return JSON.parse(dataJSON)
    } catch(e) {
        return []
    }
}

const removeNote = (title) =>{
   const notes = loadNotes()
   const noteToKeep = notes.filter((notes) => notes.title !== title )
   
  if( notes.length > noteToKeep.length) {
      saveNotes(noteToKeep)
      console.log(chalk.green.inverse('Note removed!'))
    
  } else {
      
      console.log(chalk.red.inverse('No note removed!'))
  }
  
}

const readNote = (title) => {
    const notes = loadNotes();
    const note = notes.find((note) => note.title === title )
    if(note){
      console.log(chalk.green('title: ' + note.title))
      console.log(note.body)
    } else {
     console.log(chalk.red('No note with the title: ' + title + ' is found.'))
    }
}

const listNotes = () => {
    const notes = loadNotes()
    notes.forEach(note => {
        console.log('Your notes: ' + note.title)
    });

}

module.exports = {
    addNote: addNote,
    removeNote: removeNote,
    listNotes: listNotes,
    readNote: readNote
}