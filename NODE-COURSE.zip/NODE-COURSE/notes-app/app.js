
const yargs = require('yargs')
const fs = require('fs')
const notes = require('./notes.js')
const note = require('chalk')

yargs.command({
    command: 'add',
    describe: 'Add a new note',
    builder: {
        title: {
            describe: 'Note title'
        },
        body: {
            describe: 'Note body'
        }
    },
    handler:  function(argv){
        const data = notes.addNote(argv.title, argv.body)
    }
    
})

yargs.command({
    command: 'remove',
    describe: 'Remove notes',
    builder: {
        title: {
            describe: 'Note title',
            demandOption: true,
            type: 'string'
        }
    },
    handler(argv) {
        const remove = notes.removeNote(argv.title)
        console.log(remove)

    }
})

yargs.command({
    command: 'list',
    describe: 'Get  list',
    handler(){
        const list = notes.listNotes()
    }
})

yargs.command({
    command: 'read',
    describe: 'read notes',
    builder: {
        title: {
            describe: 'Note title',
            demandOption: true,
            type: 'string'
        }
    },
    handler(arv) {
        notes.readNote(arv.title)
        console.log(arv)
    }
})  
console.log(yargs.argv)