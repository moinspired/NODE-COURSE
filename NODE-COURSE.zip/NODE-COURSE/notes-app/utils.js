console.log('utils.js')

const name = 'Mike'

exports.myDateTime = function () {
    return Date();
  };