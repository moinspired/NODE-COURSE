const request = require('request')


const url = 'http://api.weatherstack.com/current?access_key=955859f00f78902401b4bac00aa16ab1&query=37.8267,-122.4233'

request({ url: url }, (error, response) => {
    const data = JSON.parse(response.body)
    console.log(data.current)
}
)